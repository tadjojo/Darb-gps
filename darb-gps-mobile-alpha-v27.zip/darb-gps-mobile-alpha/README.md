# DARB GPS — NestJS + Flutter Mobile Alpha (integration build)

This bundle combines the verified NestJS backend alpha with the Flutter mobile source integrated against its real API contract.

## What is included

- `backend/`: NestJS 11 API, PostgreSQL/PostGIS schema, JWT login/refresh, organization/vehicle management, mobile device enrollment, authenticated location ingestion, transactional outbox, Redis Streams and authenticated Socket.IO namespace.
- `mobile/`: Flutter source with Arabic/English UI, secure token storage, login, organization and vehicle creation, mobile device enrollment, foreground GPS tracking, SQLite offline event queue, REST synchronization, token refresh, Socket.IO live updates and REST reconciliation after reconnect.
- `mobile/docs/PLATFORM_SETUP.md`: native Android/iOS runner generation and permission configuration.

## Backend setup

See `backend/README.md` and `backend/.env.example`. In summary:

1. Configure strong unique `POSTGRES_PASSWORD` and `JWT_ACCESS_SECRET` values.
2. Start PostGIS and Redis with Docker Compose.
3. Install backend dependencies and run the database migration.
4. Provision the first active account using the controlled process in `backend/docs/bootstrap-first-vehicle.sql`.
5. Start the API. The alpha has no public registration or password-reset endpoint.

## Mobile setup

See `mobile/docs/PLATFORM_SETUP.md`.

```bash
cd mobile
flutter create --platforms=android,ios .
flutter pub get
flutter run
```

The app defaults to `http://10.0.2.2:3000` for an Android emulator. On a physical device, configure the reachable API URL in Settings. Production must use HTTPS.

After signing in, the app can create an organization and vehicle, enroll the phone, and start foreground tracking. The account must already have been provisioned in the backend.

## Delivery and safety behavior

- A GPS event receives a UUID once, is saved to SQLite before sending, and reuses that UUID for every retry.
- Backend idempotency is keyed by `(device_id,event_id)`.
- Access and refresh tokens are stored using platform secure storage; refresh tokens rotate through the backend endpoint.
- Socket.IO connects to `/tracking` with the access token and joins only the selected vehicle room. On reconnect the app requests the latest location over REST.
- Tracking is foreground-only. The five-metre distance filter is not a five-second guarantee; OS scheduling, GPS accuracy, power policy and connectivity determine actual update cadence.
- The backend and mobile client remain alpha. No APK/IPA has been built from this bundle and no end-to-end runtime test against live PostgreSQL/Redis has been performed in this environment.

## Important production blockers

Before production: add account registration/verification and recovery flows, MFA, rate limits, security/audit pipeline, token and socket membership revocation fanout, retention/partition automation, observability, tested backup/restore, load/security testing, independent tracker credentials and protocol adapters, robust background location with platform disclosures, and app-store compliance review.

## Security update

The backend now records access-token JTI revocations on explicit logout. HTTP guards and new realtime connections reject revoked tokens. Existing live sockets still require a later revocation-fanout implementation. See `backend/README.md`.

### Authorization revocation

Phase 5460 adds distributed revocation notifications and a 30-second socket authorization audit. See `docs/phase-5460.md` for deployment assumptions and the required multi-instance acceptance tests. Do not treat the source alpha as production-ready until those tests pass.

### Multi-replica realtime delivery

Each API replica needs a unique stable `INSTANCE_ID` in production. The Redis Stream consumer group is derived from it unless `REALTIME_CONSUMER_GROUP` is explicitly configured. New replica groups start at the stream tail, so clients must fetch latest state over REST after connecting. See `docs/phase-5461.md` before scaling beyond one replica.

### Independent GPS tracker development

See [`docs/phase-5465-5467.md`](docs/phase-5465-5467.md) for the tracker simulator, device registry endpoints, protocol limitations and validation status.

## Android application build

The Flutter mobile source is in `mobile/`. For a reproducible Android build, install Flutter stable and Android Studio/Android SDK, then run `mobile/scripts/build-android.sh` (Linux/macOS) or `mobile/scripts/build-android.ps1` (Windows PowerShell). These scripts generate the missing Android runner, install dependencies, run analyzer/tests, and build a release APK. They have not been executed in the current build environment because Flutter/Dart/Android SDK are not installed here. See `mobile/docs/PLATFORM_SETUP.md` for backend and signing prerequisites.

## Build Android APK in GitHub Actions

A hosted build workflow is included at `.github/workflows/android-debug-apk.yml`.
After this project is pushed to a GitHub repository:

1. Open the repository's **Actions** tab.
2. Select **DARB Android debug APK**.
3. Choose **Run workflow** (or push a change under `mobile/`).
4. Wait for the `android-debug` job to finish successfully.
5. Download the `darb-gps-android-debug-*` artifact from that run and extract `app-debug.apk`.

This produces a **debug/testing APK**, signed with the standard debug key by the Android Gradle build. It is suitable for installation on a test Android device, but is not a production release. A production APK/AAB must be signed with a privately controlled release keystore; never commit that keystore or its passwords to the repository. The workflow does not publish to Google Play.

The workflow runs Flutter dependency resolution, static analysis, tests, and APK build on GitHub-hosted infrastructure. A green workflow is the first actual compiler/test result; until it runs successfully, the project must still be treated as unbuilt alpha software.


## Android background tracking (phase 10)

The mobile source now requests Android foreground location tracking through Geolocator's `AndroidSettings`, with an ongoing notification and wake-lock request. The user must grant location access and start tracking while the app is visible; Android continues the user-started location foreground service in the background subject to OS/device restrictions. The 5-second interval is a request, not a guaranteed delivery rate. See `mobile/docs/ANDROID_BACKGROUND_TRACKING.md` before testing or release. iOS background tracking is not yet implemented.


## Phase 13 — GPS recovery

The mobile source now retries an interrupted GPS stream with bounded backoff, prevents stale callbacks from reviving a stopped session, and rejects invalid/old location fixes. See `docs/phase-13-gps-recovery.md`. This source change is not Flutter-build-verified; a Dart/Flutter SDK and physical-device tests are still required.

## Phase 14 — navigation provider adapter

`mobile/lib/services/navigation_service.dart` adds provider-isolated place search (Nominatim-compatible) and driving route retrieval (OSRM-compatible), including alternative routes, coordinate validation, GeoJSON-to-LatLng conversion, and injectable HTTP clients. Unit tests are in `mobile/test/services/navigation_service_test.dart`. This is the navigation data layer only; the user-facing route-selection/navigation screen, voice guidance, rerouting and offline maps remain pending. Public demo routing/geocoding endpoints must not be treated as production infrastructure. See `mobile/docs/NAVIGATION_ALPHA.md`.

The map screen is now wired to the navigation adapter: submit a place/address search, select a result, and the app requests and draws a driving route with distance/ETA and alternative-route cycling. This integration remains source-level until Flutter analysis, tests and a device run are completed.

## Phase 15 — mobile device registry

The Vehicles screen now retrieves the authenticated vehicle device list and displays provisioned mobile/GPS tracker devices, connection state, manufacturer/model, last protocol and battery telemetry. Tracker credential provisioning and per-model physical-device certification remain administrative/backend tasks. See `mobile/docs/DEVICE_REGISTRY_MOBILE.md`.

## Deployment handoff

For server setup, app network configuration, backup, and pilot acceptance, follow [`backend/DEPLOYMENT_RUNBOOK.md`](backend/DEPLOYMENT_RUNBOOK.md). After starting the stack, run `backend/scripts/check-stack.sh` from the backend directory. The Android emulator default URL is not valid on a physical phone; configure the reachable HTTPS API URL in app settings.


## v27 CI update

The backend GitHub Actions pipeline now executes the dependency-free GPS simulator smoke test before installing application packages. The test validates the simulator's local HTTP send/replay behavior; live backend, PostGIS, Redis, and physical tracker acceptance remain separate gates.
