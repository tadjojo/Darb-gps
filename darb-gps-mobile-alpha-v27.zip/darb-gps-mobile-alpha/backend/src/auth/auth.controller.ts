import { Body, Controller, HttpCode, HttpStatus, Post, Headers, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { RefreshDto } from './dto/refresh.dto';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly auth: AuthService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
  ) {}

  @Post('login')
  @HttpCode(HttpStatus.OK)
  login(@Body() dto: LoginDto) {
    return this.auth.login(dto.identifier, dto.password);
  }

  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  refresh(@Body() dto: RefreshDto) {
    return this.auth.refresh(dto.refreshToken);
  }

  @Post('logout')
  @HttpCode(HttpStatus.NO_CONTENT)
  async logout(@Body() dto: RefreshDto, @Headers('authorization') authorization?: string): Promise<void> {
    let jti: string | undefined;
    let expiresAt: Date | undefined;
    if (authorization) {
      if (!/^Bearer\s+\S+$/i.test(authorization)) throw new UnauthorizedException('Invalid authorization header');
      try {
        const claims = await this.jwt.verifyAsync<{ jti?: string; exp?: number }>(
          authorization.replace(/^Bearer\s+/i, ''),
          { secret: this.config.getOrThrow<string>('JWT_ACCESS_SECRET'), algorithms: ['HS256'] },
        );
        if (!claims.jti || !claims.exp) throw new Error('Missing token claims');
        jti = claims.jti;
        expiresAt = new Date(claims.exp * 1000);
      } catch {
        throw new UnauthorizedException('Invalid or expired access token');
      }
    }
    await this.auth.logout(dto.refreshToken, jti, expiresAt);
  }
}
