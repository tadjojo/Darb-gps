import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';
import { TokenRevocationCleanup } from './token-revocation-cleanup';

@Module({
  imports: [JwtModule.registerAsync({
    inject: [ConfigService],
    useFactory: (config: ConfigService) => ({
      secret: config.getOrThrow<string>('JWT_ACCESS_SECRET'),
      signOptions: { expiresIn: config.get<number>('JWT_ACCESS_TTL_SECONDS', 600) },
      verifyOptions: { algorithms: ['HS256'] },
    }),
  })],
  controllers: [AuthController],
  providers: [AuthService, JwtAuthGuard, TokenRevocationCleanup],
  exports: [JwtModule, JwtAuthGuard],
})
export class AuthModule {}
