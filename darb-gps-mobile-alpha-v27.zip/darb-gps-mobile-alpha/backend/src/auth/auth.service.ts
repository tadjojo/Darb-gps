import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { Injectable, UnauthorizedException, Inject, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Pool } from 'pg';
import * as bcrypt from 'bcryptjs';
import { PG_POOL } from '../database/database.constants';
import { AuthTokens } from './auth.types';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @Inject(PG_POOL) private readonly pool: Pool,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
  ) {}

  private hashRefreshToken(token: string): string {
    return createHash('sha256').update(token, 'utf8').digest('hex');
  }

  private async createTokenPair(user: { id: string; email?: string | null; phone_e164?: string | null }): Promise<AuthTokens> {
    const accessTtl = this.config.get<number>('JWT_ACCESS_TTL_SECONDS', 600);
    const refreshDays = this.config.get<number>('REFRESH_TOKEN_TTL_DAYS', 30);
    const jti = randomUUID();
    const accessToken = await this.jwt.signAsync({
      sub: user.id,
      jti,
      email: user.email ?? undefined,
      phone: user.phone_e164 ?? undefined,
    }, { expiresIn: accessTtl });

    const refreshToken = randomBytes(48).toString('base64url');
    const expiresAt = new Date(Date.now() + refreshDays * 86400_000);
    await this.pool.query(
      `INSERT INTO refresh_sessions (user_id, token_hash, expires_at)
       VALUES ($1, $2, $3)`,
      [user.id, this.hashRefreshToken(refreshToken), expiresAt],
    );

    return { accessToken, refreshToken, tokenType: 'Bearer', expiresIn: accessTtl };
  }

  async login(identifier: string, password: string): Promise<AuthTokens> {
    const normalized = identifier.trim();
    const result = await this.pool.query(
      `SELECT id, email, phone_e164, password_hash, status
         FROM app_users
        WHERE lower(email) = lower($1) OR phone_e164 = $1
        LIMIT 1`,
      [normalized],
    );
    const user = result.rows[0];
    // Same external response for unknown user, disabled user, and wrong password.
    const valid = Boolean(user?.password_hash) && await bcrypt.compare(password, user.password_hash);
    if (!valid || user.status !== 'active') {
      throw new UnauthorizedException('Invalid credentials');
    }
    return this.createTokenPair(user);
  }

  async refresh(presentedToken: string): Promise<AuthTokens> {
    const tokenHash = this.hashRefreshToken(presentedToken);
    const client = await this.pool.connect();
    let user: { id: string; email: string | null; phone_e164: string | null } | undefined;
    try {
      await client.query('BEGIN');
      const sessionResult = await client.query(
        `SELECT s.id AS session_id, s.user_id, s.expires_at, s.revoked_at,
                u.email, u.phone_e164, u.status
           FROM refresh_sessions s
           JOIN app_users u ON u.id = s.user_id
          WHERE s.token_hash = $1
          FOR UPDATE OF s`,
        [tokenHash],
      );
      const session = sessionResult.rows[0];
      if (!session || session.revoked_at || new Date(session.expires_at).getTime() <= Date.now() || session.status !== 'active') {
        throw new UnauthorizedException('Invalid refresh token');
      }
      user = { id: session.user_id, email: session.email, phone_e164: session.phone_e164 };
      await client.query('UPDATE refresh_sessions SET revoked_at = now() WHERE id = $1', [session.session_id]);
      const refreshDays = this.config.get<number>('REFRESH_TOKEN_TTL_DAYS', 30);
      const newRefreshToken = randomBytes(48).toString('base64url');
      const newSession = await client.query(
        `INSERT INTO refresh_sessions (user_id, token_hash, expires_at)
         VALUES ($1, $2, now() + ($3 * interval '1 day'))
         RETURNING id`,
        [user.id, this.hashRefreshToken(newRefreshToken), refreshDays],
      );
      await client.query(
        'UPDATE refresh_sessions SET replaced_by = $1 WHERE token_hash = $2',
        [newSession.rows[0].id, tokenHash],
      );
      await client.query('COMMIT');

      const accessTtl = this.config.get<number>('JWT_ACCESS_TTL_SECONDS', 600);
      const accessToken = await this.jwt.signAsync({ sub: user.id, jti: randomUUID(), email: user.email ?? undefined, phone: user.phone_e164 ?? undefined }, { expiresIn: accessTtl });
      return { accessToken, refreshToken: newRefreshToken, tokenType: 'Bearer', expiresIn: accessTtl };
    } catch (error) {
      await client.query('ROLLBACK').catch(() => undefined);
      if (error instanceof UnauthorizedException) throw error;
      this.logger.error('Refresh operation failed');
      throw error;
    } finally {
      client.release();
    }
  }

  async logout(presentedToken: string, accessJti?: string, accessExpiresAt?: Date): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `UPDATE refresh_sessions SET revoked_at = COALESCE(revoked_at, now())
          WHERE token_hash = $1`,
        [this.hashRefreshToken(presentedToken)],
      );
      if (accessJti && accessExpiresAt && accessExpiresAt.getTime() > Date.now()) {
        await client.query(
          `INSERT INTO revoked_access_tokens (jti, expires_at) VALUES ($1, $2)
           ON CONFLICT (jti) DO NOTHING`,
          [accessJti, accessExpiresAt],
        );
        // PostgreSQL delivers NOTIFY only after this transaction commits.
        await client.query(
          `SELECT pg_notify('darb_access_revoked', $1)`,
          [JSON.stringify({ jti: accessJti })],
        );
      }
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK').catch(() => undefined);
      throw error;
    } finally { client.release(); }
  }
}
