import type { Request } from 'express';

export interface AuthenticatedUser {
  sub: string;
  jti: string;
  email?: string;
  phone?: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  tokenType: 'Bearer';
  expiresIn: number;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthenticatedUser;
}
