import { CanActivate, ExecutionContext, Injectable, UnauthorizedException, Inject } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Pool } from 'pg';
import { PG_POOL } from '../database/database.constants';
import { AuthenticatedRequest, AuthenticatedUser } from './auth.types';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly jwt: JwtService,
    @Inject(PG_POOL) private readonly pool: Pool,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    const header = request.headers.authorization;
    if (!header || !/^Bearer\s+\S+$/i.test(header)) throw new UnauthorizedException();
    const token = header.replace(/^Bearer\s+/i, '');
    let user: AuthenticatedUser;
    try {
      user = await this.jwt.verifyAsync<AuthenticatedUser>(token, { algorithms: ['HS256'] });
      if (!user.sub || !user.jti) throw new Error('Missing token claims');
    } catch {
      throw new UnauthorizedException('Invalid or expired access token');
    }
    const active = await this.pool.query(
      `SELECT 1 FROM app_users u
        WHERE u.id = $1 AND u.status = 'active'
          AND NOT EXISTS (SELECT 1 FROM revoked_access_tokens r WHERE r.jti = $2 AND r.expires_at > now())`, [user.sub, user.jti],
    );
    if (!active.rowCount) throw new UnauthorizedException('Account is not active');
    request.user = user;
    return true;
  }
}
