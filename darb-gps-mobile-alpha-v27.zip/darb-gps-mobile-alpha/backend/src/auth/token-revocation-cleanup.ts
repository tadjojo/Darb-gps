import { Inject, Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { Pool } from 'pg';
import { PG_POOL } from '../database/database.constants';

@Injectable()
export class TokenRevocationCleanup implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(TokenRevocationCleanup.name);
  private timer?: NodeJS.Timeout;
  private running = false;

  constructor(@Inject(PG_POOL) private readonly pool: Pool) {}

  onModuleInit(): void {
    // Run once at startup, then every 15 minutes. Expired JWTs no longer need
    // deny-list rows; old refresh sessions are retained for a 90-day audit window.
    void this.cleanup();
    this.timer = setInterval(() => { void this.cleanup(); }, 15 * 60_000);
    this.timer.unref?.();
  }

  onModuleDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  private async cleanup(): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      const revoked = await this.pool.query(
        `DELETE FROM revoked_access_tokens WHERE expires_at <= now()`
      );
      const sessions = await this.pool.query(
        `DELETE FROM refresh_sessions
          WHERE (expires_at < now() - interval '90 days'
             OR (revoked_at IS NOT NULL AND revoked_at < now() - interval '90 days'))
            AND NOT EXISTS (SELECT 1 FROM refresh_sessions child WHERE child.replaced_by = refresh_sessions.id)`
      );
      if ((revoked.rowCount ?? 0) + (sessions.rowCount ?? 0) > 0) {
        this.logger.log(`Authorization cleanup removed ${revoked.rowCount ?? 0} expired access revocations and ${sessions.rowCount ?? 0} old refresh sessions`);
      }
    } catch (error) {
      this.logger.error('Authorization cleanup failed', error instanceof Error ? error.stack : undefined);
    } finally {
      this.running = false;
    }
  }
}
