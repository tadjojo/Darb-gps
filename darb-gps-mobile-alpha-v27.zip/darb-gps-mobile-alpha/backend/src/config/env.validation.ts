import * as Joi from 'joi';

export const environmentSchema = Joi.object({
  NODE_ENV: Joi.string().valid('development', 'test', 'production').default('development'),
  PORT: Joi.number().port().default(3000),
  API_PREFIX: Joi.string().pattern(/^[a-zA-Z0-9/_-]+$/).default('api/v1'),
  DATABASE_URL: Joi.string().uri({ scheme: ['postgres', 'postgresql'] }).required(),
  REDIS_URL: Joi.string().uri({ scheme: ['redis', 'rediss'] }).when('NODE_ENV', {
    is: 'production', then: Joi.required(), otherwise: Joi.optional(),
  }),
  REDIS_STREAM_KEY: Joi.string().default('darb:events'),
  // Must be unique and stable for each API replica in production.
  INSTANCE_ID: Joi.string().min(1).max(64).when('NODE_ENV', {
    is: 'production', then: Joi.required(), otherwise: Joi.optional().default('local'),
  }),
  REALTIME_CONSUMER_GROUP: Joi.string().min(1).max(128).optional(),
  JWT_ACCESS_SECRET: Joi.string().min(32).required(),
  JWT_ACCESS_TTL_SECONDS: Joi.number().integer().min(60).max(3600).default(600),
  REFRESH_TOKEN_TTL_DAYS: Joi.number().integer().min(1).max(90).default(30),
  DB_POOL_MAX: Joi.number().integer().min(1).max(100).default(10),
  DB_IDLE_TIMEOUT_MS: Joi.number().integer().min(1000).default(30000),
  DB_CONNECTION_TIMEOUT_MS: Joi.number().integer().min(500).default(5000),
  CORS_ORIGINS: Joi.string().default(''),
  TRACKER_TCP_HOST: Joi.string().default('0.0.0.0'),
  TRACKER_TCP_PORT: Joi.number().port().optional(),
  TRACKER_TCP_MAX_CLIENTS: Joi.number().integer().min(1).max(10000).default(500),
}).unknown(true);
