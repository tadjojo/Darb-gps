const fs = require('node:fs');
const path = require('node:path');

exports.up = (pgm) => {
  const sql = fs.readFileSync(path.join(__dirname, '001_initial_schema.sql'), 'utf8');
  pgm.sql(sql);
};

exports.down = (pgm) => {
  pgm.sql(`
    DROP TABLE IF EXISTS revoked_access_tokens CASCADE;
    DROP TABLE IF EXISTS event_outbox CASCADE;
    DROP TABLE IF EXISTS vehicle_latest_locations CASCADE;
    DROP TABLE IF EXISTS locations CASCADE;
    DROP TABLE IF EXISTS tracking_devices CASCADE;
    DROP TABLE IF EXISTS vehicle_members CASCADE;
    DROP TABLE IF EXISTS organization_members CASCADE;
    DROP TABLE IF EXISTS vehicles CASCADE;
    DROP TABLE IF EXISTS refresh_sessions CASCADE;
    DROP TABLE IF EXISTS app_users CASCADE;
    DROP TABLE IF EXISTS organizations CASCADE;
  `);
};
