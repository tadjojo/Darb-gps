-- DARB GPS alpha foundation. Apply through a controlled migration process.
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  phone_e164 text UNIQUE,
  password_hash text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled','pending')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (email IS NOT NULL OR phone_e164 IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','closed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS organization_members (
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('org_admin','fleet_supervisor','dispatcher','driver','viewer')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','invited','revoked')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (organization_id, user_id)
);

CREATE TABLE IF NOT EXISTS vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid REFERENCES organizations(id) ON DELETE RESTRICT,
  display_name text NOT NULL,
  registration_number text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','maintenance','archived')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS vehicles_org_idx ON vehicles(organization_id);

CREATE TABLE IF NOT EXISTS vehicle_members (
  vehicle_id uuid NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('owner','manager','driver','viewer')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (vehicle_id, user_id)
);
CREATE INDEX IF NOT EXISTS vehicle_members_user_idx ON vehicle_members(user_id, status);

CREATE TABLE IF NOT EXISTS tracking_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid NOT NULL REFERENCES vehicles(id) ON DELETE RESTRICT,
  enrolled_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  device_type text NOT NULL CHECK (device_type IN ('mobile','gps_tracker')),
  credential_hash text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','revoked')),
  enrolled_at timestamptz,
  last_seen_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tracking_devices_vehicle_idx ON tracking_devices(vehicle_id);

CREATE TABLE IF NOT EXISTS locations (
  id bigserial PRIMARY KEY,
  device_id uuid NOT NULL REFERENCES tracking_devices(id) ON DELETE RESTRICT,
  vehicle_id uuid NOT NULL REFERENCES vehicles(id) ON DELETE RESTRICT,
  event_id uuid NOT NULL,
  position geography(Point, 4326) NOT NULL,
  speed_kmh real CHECK (speed_kmh IS NULL OR speed_kmh BETWEEN 0 AND 400),
  heading real CHECK (heading IS NULL OR heading BETWEEN 0 AND 360),
  accuracy_m real NOT NULL CHECK (accuracy_m BETWEEN 0 AND 10000),
  recorded_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  source text NOT NULL DEFAULT 'mobile',
  UNIQUE (device_id, event_id)
);
CREATE INDEX IF NOT EXISTS locations_vehicle_recorded_idx ON locations(vehicle_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS locations_position_gix ON locations USING GIST(position);

CREATE TABLE IF NOT EXISTS vehicle_latest_locations (
  vehicle_id uuid PRIMARY KEY REFERENCES vehicles(id) ON DELETE CASCADE,
  location_id bigint NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  recorded_at timestamptz NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS event_outbox (
  id bigserial PRIMARY KEY,
  event_type text NOT NULL,
  aggregate_id uuid NOT NULL,
  payload jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processing','published','failed')),
  attempts integer NOT NULL DEFAULT 0,
  available_at timestamptz NOT NULL DEFAULT now(),
  lease_owner text,
  lease_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz
);
CREATE INDEX IF NOT EXISTS event_outbox_claim_idx ON event_outbox(status, available_at, id);


CREATE TABLE IF NOT EXISTS refresh_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  token_hash char(64) NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  replaced_by uuid REFERENCES refresh_sessions(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (revoked_at IS NULL OR revoked_at >= created_at)
);
CREATE INDEX IF NOT EXISTS refresh_sessions_user_active_idx
  ON refresh_sessions(user_id, expires_at) WHERE revoked_at IS NULL;


-- Revokes already-issued short-lived access tokens on explicit logout.
CREATE TABLE IF NOT EXISTS revoked_access_tokens (
  jti uuid PRIMARY KEY,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS revoked_access_tokens_expiry_idx ON revoked_access_tokens(expires_at);
